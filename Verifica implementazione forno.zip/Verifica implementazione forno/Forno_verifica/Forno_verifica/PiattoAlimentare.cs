﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public abstract class PiattoAlimentare //essendo classe atratta non serve il costruttore perchè non è implementabile
{
    protected string nome;
    protected int tempoCottura;
    protected int temperaturaCottura;
    protected bool cotto;
    protected DateTime inizioCottura;  //DateTime è un tipo complesso
    protected DateTime fineCottura;

    public PiattoAlimentare() 
    {
        this.nome = "";
        this.tempoCottura = 0;
        this.temperaturaCottura = 0;
        this.cotto = false;
        this.inizioCottura = new DateTime(0);
        this.fineCottura = new DateTime(0);
    }

    public string Nome
    {
        get { return nome; }
    }

    public int TempoCottura
    {
        get { return tempoCottura; }
    }

    public int TemperaturaCottura
    {
        get { return temperaturaCottura; }
    }

    public bool Cotto
    {
        get { return cotto; }
    }

    public DateTime InizioCottura
    {
        get 
        { 
            if (cotto == true)
            {
                return inizioCottura;
            } 
            return new DateTime(0);
        }
    }

    public DateTime FineCottura
    {
        get
        {
            if (cotto == true)
            {
                return fineCottura;
            }
            return new DateTime(0);
        }
    }

    public abstract void Cuoci();
}

