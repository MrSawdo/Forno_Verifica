﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Forno
{

    protected string id;  //ho cambiato da private a protected
    protected string produttore;
    protected string modello;
    protected string stato;
    protected PiattoAlimentare? contenuto; //il punto di domanda sta per nullable, cioe che puoi mettero a null
    private int manutenzioneProgrammata; //non si imposta qua perchè in caso di altre classi che richiedono la manutenzione con un numero diverso, il numero rimarrebbe quello

    public Forno(string id, string produttore, string modello) 
    {
        this.id = id;
        this.produttore = produttore;
        this.modello = modello;
        this.stato = "Spento";
        this.contenuto = null;
        this.manutenzioneProgrammata = 365;
    }
    public string Id
    {
        get { return id; }
    }

    public string Produttore
    {
        get { return produttore; }
    }

    public string Modello
    {
        get { return modello; }
    }

    public string Stato
    {
        get { return stato; }
    }

    public int ManutenzioneProgrammata
    {
        get { return manutenzioneProgrammata; }
    }


    public string Accendi()
    {
        if (stato == "Spento")
        {
            if (manutenzioneProgrammata > 0)
            {
                stato = "Acceso";
                Console.WriteLine("| Forno acceso");
                manutenzioneProgrammata -= 1;
                Console.WriteLine("| " + manutenzioneProgrammata + " accensioni rimanenti");
            }
        }
        return stato;
    }

    public string Spegni()
    {
        stato = "Spento";
        Console.WriteLine("| Forno spento");
        return stato;
    }

    public PiattoAlimentare? Cuocere()
    {
        PiattoAlimentare? piatto = null;
        if (stato == "Acceso" && contenuto != null)
        {
            Console.WriteLine("| sto cuocendo");
            piatto = contenuto;
            piatto.Cuoci();
            contenuto = null;
        }
        return piatto;
    }

    public string InserisciPiatto(PiattoAlimentare piatto)
    {
        if(contenuto == null)
        {
            contenuto = piatto;
            Console.WriteLine("| Piatto inserito");
            return "Piatto inserito";
        }
        else
        {
            Console.WriteLine("| Il forno è pieno");
            return "Il forno è pieno";
        }
    }

    public PiattoAlimentare? RimuoviPiatto()
    {
        PiattoAlimentare? piatto = null;
        if (contenuto != null)
        {
            Console.WriteLine("| Piatto rimosso");
            piatto = contenuto;
            contenuto = null;
        }
        return piatto;
    }
}
