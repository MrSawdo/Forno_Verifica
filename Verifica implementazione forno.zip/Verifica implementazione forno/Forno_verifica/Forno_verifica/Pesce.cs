﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

public class Pesce : PiattoAlimentare
{
    private string tipoSpecifico;

    public Pesce(string nome, string tipoSpecifico)
    {
        this.nome = nome;
        this.tipoSpecifico = tipoSpecifico;
        this.temperaturaCottura = 180;
        this.tempoCottura = CalcolaTempoCottura();
    }

    public string TipoSpecifico
    {
        get { return tipoSpecifico; }
    }

    private int CalcolaTempoCottura()
    {
        if(this.tipoSpecifico == "Salmone")
        {
            return 25;
        }
        else
        {
            return 30;
        }
    }

    public override void Cuoci() 
    {
        this.inizioCottura = DateTime.Now;
        this.fineCottura = this.inizioCottura.AddMinutes(this.tempoCottura + 3);
        this.cotto = true;
    }
}

