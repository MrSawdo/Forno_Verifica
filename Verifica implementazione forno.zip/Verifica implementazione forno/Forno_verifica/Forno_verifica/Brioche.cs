﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Brioche : PiattoAlimentare
{
    private int qtaZuccheri;

    public Brioche(string nome, int qtaZuccheri)
    {
        this.nome = nome;
        this.qtaZuccheri = qtaZuccheri;
        this.temperaturaCottura = 220;
        this.tempoCottura = 60;
    }

    public int QtaZuccheri
    {
        get { return qtaZuccheri; }
    }

    public override void Cuoci()
    {
        this.inizioCottura = DateTime.Now;
        this.fineCottura = this.inizioCottura.AddMinutes(this.tempoCottura);
        this.cotto = true;
    }
}
