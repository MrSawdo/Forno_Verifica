﻿using System.ComponentModel.Design;

class Verifica
{
    static void Main(string[] args)
    {
        Forno f = new Forno("00001", "Shuai", "Oulib");
        Torta p1 = new Torta("Torta", 150, 400);
        Pesce p2 = new Pesce("Pesce", "Salmone");
        Brioche p3 = new Brioche("Cioccolato", 6);
        Pesce p4 = new Pesce("Pesce", "Salmone");
        
        

        Console.WriteLine("| {" + p1.Nome + ", " + p1.QtaZuccheri + ", " + p1.Diametro + "}");
        Console.WriteLine("| {" + p1.Cotto + ", " + p1.InizioCottura + ", " + p1.FineCottura + "}");
        f.InserisciPiatto(p1);
        f.Accendi();
        f.Cuocere();
        f.Spegni();
        f.RimuoviPiatto();  
        Console.WriteLine("| {" + p1.Nome + ", " + p1.QtaZuccheri + ", " + p1.Diametro + "}");
        Console.WriteLine("| {" + p1.Cotto + ", " + p1.InizioCottura + ", " + p1.FineCottura + "}");
        Console.WriteLine();



        Console.WriteLine("| {" + p2.Nome + ", " + p2.TipoSpecifico + "}");
        Console.WriteLine("| {" + p2.Cotto + ", " + p2.InizioCottura + ", " + p2.FineCottura + "}");
        f.InserisciPiatto(p2);
        f.Accendi();
        f.Cuocere();
        f.Spegni();
        f.RimuoviPiatto();
        Console.WriteLine("| {" + p2.Nome + ", " + p2.TipoSpecifico + "}");
        Console.WriteLine("| {" + p2.Cotto + ", " + p2.InizioCottura + ", " + p2.FineCottura + "}");
        Console.WriteLine();



        Console.WriteLine("| {" + p3.Nome + ", " + p3.QtaZuccheri + "}");
        Console.WriteLine("| {" + p3.Cotto + ", " + p3.InizioCottura + ", " + p3.FineCottura + "}");
        f.InserisciPiatto(p3);
        f.Accendi();
        f.Cuocere();
        f.Spegni();
        f.RimuoviPiatto();
        Console.WriteLine("| {" + p3.Nome + ", " + p3.QtaZuccheri + "}");
        Console.WriteLine("| {" + p3.Cotto + ", " + p3.InizioCottura + ", " + p3.FineCottura + "}");
        Console.WriteLine();



        FornoPremium fp = new FornoPremium("00002", "Shuai", "Oulib+");
        Console.WriteLine("| {" + p4.Nome + ", " + p4.TipoSpecifico + "}");
        Console.WriteLine("| {" + p4.Cotto + ", " + p4.InizioCottura + ", " + p4.FineCottura + "}");
        fp.InserisciPiatto(p4);
        fp.Accendi();
        fp.Cuocere();
        fp.Spegni();
        fp.RimuoviPiatto();
        Console.WriteLine("| {" + p4.Nome + ", " + p4.TipoSpecifico + "}");
        Console.WriteLine("| {" + p4.Cotto + ", " + p4.InizioCottura + ", " + p4.FineCottura + "}");
        Console.WriteLine();
    }
}