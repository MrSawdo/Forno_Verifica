﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

public class Torta : PiattoAlimentare
{
    private int qtaZuccheri;
    public int diametro;

    public Torta(string nome, int qtaZuccheri, int diametro)
    {
        this.nome = nome;
        this.qtaZuccheri = qtaZuccheri;
        this.diametro = diametro;
        this.temperaturaCottura = 200;
        this.tempoCottura = CalcolaTempoCottura(diametro);
    }

    public int QtaZuccheri
    {
        get { return qtaZuccheri; }
    }

    public int Diametro
    {
        get { return diametro; }
        set { diametro = value; }
    }

    private int CalcolaTempoCottura(int diametro)
    {
        return (diametro / 100) * 2;
    }

    public override void Cuoci()
    {
        this.inizioCottura = DateTime.Now;
        this.fineCottura = this.inizioCottura.AddMinutes(this.tempoCottura);
        this.cotto = true;
    }
}

