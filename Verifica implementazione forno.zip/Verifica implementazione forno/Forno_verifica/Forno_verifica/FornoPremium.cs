﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class FornoPremium : Forno
{
    public FornoPremium(string id, string produttore, string modello): base (id, produttore, modello) // chiama il costruttore della classe base
    {
    }

    public new string Accendi()
    {
        if (stato == "Spento")
        {
            stato = "Acceso";   
        }
        return stato;
    }
}